
import React, { useEffect, useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, Package, ArrowRight, Star } from 'lucide-react';

const EmojiConfetti: React.FC = () => {
  const [items, setItems] = useState<{ id: number; left: number; delay: number; duration: number; size: number }[]>([]);

  useEffect(() => {
    // Generate 50 emojis with random properties
    const newItems = Array.from({ length: 60 }).map((_, i) => ({
      id: i,
      left: Math.random() * 100, // percentage
      delay: Math.random() * 2, // seconds
      duration: 3 + Math.random() * 3, // seconds
      size: 20 + Math.random() * 30, // pixels
    }));
    setItems(newItems);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-[150] overflow-hidden">
      {items.map((item) => (
        <div
          key={item.id}
          className="absolute top-[-50px] animate-emoji-fall opacity-0"
          style={{
            left: `${item.left}%`,
            animationDelay: `${item.delay}s`,
            animationDuration: `${item.duration}s`,
            fontSize: `${item.size}px`,
          }}
        >
          🥳
        </div>
      ))}
      <style>{`
        @keyframes emoji-fall {
          0% {
            transform: translateY(0) rotate(0deg);
            opacity: 1;
          }
          100% {
            transform: translateY(110vh) rotate(360deg);
            opacity: 1;
          }
        }
        .animate-emoji-fall {
          animation-name: emoji-fall;
          animation-timing-function: linear;
          animation-fill-mode: forwards;
        }
      `}</style>
    </div>
  );
};

const OrderSuccess: React.FC = () => {
  const orderId = useMemo(() => `SM-${Math.floor(100000 + Math.random() * 900000)}`, []);

  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center py-20 px-4 relative">
      <EmojiConfetti />
      
      <div className="max-w-xl w-full text-center space-y-8 animate-in fade-in zoom-in duration-700 relative z-10">
        <div className="relative inline-block">
          <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto text-green-600">
            <CheckCircle size={56} />
          </div>
          <div className="absolute -top-2 -right-2 w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center shadow-lg animate-bounce">
            <Star size={16} />
          </div>
        </div>

        <div className="space-y-4">
          <h1 className="text-4xl font-black text-gray-900 leading-tight">Order Placed Successfully!</h1>
          <p className="text-gray-500 text-lg">
            Thank you for choosing SoleMate. Your order <span className="text-indigo-600 font-bold font-mono">#{orderId}</span> has been confirmed.
          </p>
        </div>

        <div className="bg-gray-50 p-8 rounded-[2.5rem] border border-gray-100 space-y-6 text-left">
          <div className="flex items-start space-x-4">
            <div className="w-10 h-10 bg-white rounded-xl shadow-sm border border-gray-100 flex items-center justify-center shrink-0">
              <Package className="text-indigo-600" size={20} />
            </div>
            <div>
              <h4 className="font-bold text-gray-900">Dispatch Pending</h4>
              <p className="text-sm text-gray-500 leading-relaxed">We've received your order and are currently preparing your items for shipping. Expect an update within 24 hours.</p>
            </div>
          </div>
          
          <div className="flex items-start space-x-4">
            <div className="w-10 h-10 bg-white rounded-xl shadow-sm border border-gray-100 flex items-center justify-center shrink-0">
              <Star className="text-yellow-400" size={20} />
            </div>
            <div>
              <h4 className="font-bold text-gray-900">Stay fresh, stay comfortable</h4>
              <p className="text-sm text-gray-500 leading-relaxed">Don't forget to tag us <span className="text-indigo-600 font-bold">@SoleMateCare</span> when you unbox your new gear!</p>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 pt-4">
          <Link 
            to="/" 
            className="flex-1 px-8 py-4 bg-gray-900 text-white font-bold rounded-2xl hover:bg-gray-800 transition shadow-xl"
          >
            Back to Home
          </Link>
          <Link 
            to="/shop" 
            className="flex-1 px-8 py-4 bg-indigo-600 text-white font-bold rounded-2xl hover:bg-indigo-700 transition shadow-xl flex items-center justify-center"
          >
            Continue Shopping <ArrowRight className="ml-2" size={20} />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default OrderSuccess;
